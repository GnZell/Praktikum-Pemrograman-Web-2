<?php

namespace App\Controllers;

use App\Models\biodatamodel;

class Home extends BaseController
{
    public function index()
    {
        $mahasiswa = new biodatamodel();
        return view('index', [
            "nama" => $mahasiswa->getNama(),
            "nim" => $mahasiswa->getNim(),
        ]);
    }
    public function biodata()
    {
        $mahasiswa = new biodatamodel();
        return view('biodata', [
            "nama" => $mahasiswa->getNama(),
            "ttl" => $mahasiswa->getTTL(),
            "nim" => $mahasiswa->getNim(),
            "citacita" => $mahasiswa->getcita_cita(),
            "prodi" => $mahasiswa->getProdi(),
            "hobi" => $mahasiswa->gethobi(),

            "foto1" => $mahasiswa->getFoto1()
        ]);
    }
}