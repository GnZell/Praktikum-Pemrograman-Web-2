<!DOCTYPE html>
<html>

<head>
    <title>Biodata Pribadi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        padding: 20px;
        background-image: url("../images/bg.jpg");
        background-size: cover;
    }
    ::selection {
    background-color: rgba(0, 0, 0, 0);
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        margin-top: 10px;

        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border-radius: 20px;

    background: radial-gradient(circle, white 0%, #d5d5d5 100%);

    border-radius: 20px;
    position: relative;
    box-shadow: 3px 3px 17px 0px rgba(0, 0, 0, 0.55);
    }

    h1 {
        text-align: center;
        margin-bottom: 30px;
    }

    table {
        width: 100%;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
    }

    th {
        width: 30%;
    }

    .profile-img {
        width: 250px;
        height: 350px;
        border-radius: 10%;
        object-fit: cover;
        object-position: center;
        box-shadow: -6px 2px 20px 8px #A89D9D;
    }

    .btn-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .btn-donate {
    --clr-font-main: hsla(0 0% 20% / 100);
    --btn-bg-1: #e9ebea;
    --btn-bg-2: silver;
    --btn-bg-color: black;
    --radii: 0.5em;
    cursor: pointer;
    padding: 0.9em 1.4em;
    min-width: 120px;
    min-height: 44px;
    font-size: var(--size, 1rem);
    font-family: "Segoe UI", system-ui, sans-serif;
    font-weight: 500;
    transition: 0.8s;
    background-size: 280% auto;
    background-image: linear-gradient(325deg, var(--btn-bg-2) 0%, var(--btn-bg-1) 55%, var(--btn-bg-2) 90%);
    border: none;
    border-radius: var(--radii);
    color: var(--btn-bg-color);
    /* box-shadow: 0px 0px 20px rgba(71, 184, 255, 0.5), 0px 5px 5px -1px rgba(58, 125, 233, 0.25), inset 4px 4px 8px rgba(175, 230, 255, 0.5), inset -4px -4px 8px rgba(19, 95, 216, 0.35); */
    }

    .btn-donate:hover {
    background-position: right top;
    }

    .btn-donate:is(:focus, :focus-within,:active) {
    outline: none;
    box-shadow: 0 0 0 3px var(--btn-bg-color), 0 0 0 6px var(--btn-bg-2);
    }

    @media (prefers-reduced-motion: reduce) {
    .btn-donate {
        transition: linear;
    }
    }
    </style>
</head>

<body>
    <div class="container">
        <h1>Biodata Pribadi</h1>

        <table>
            <tr>
                <td rowspan="8"><img src="<?= base_url('images/' . $foto1) ?>" class="profile-img">
                </td>
                <th>Nama Lengkap</th>
                <td>
                    <?= $nama; ?>
                </td>
            </tr>
            <tr>
                <th>TTL</th>
                <td>
                    <?= $ttl; ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim; ?>
                </td>
            </tr>
            <tr>
                <th>Asal Prodi</th>
                <td>
                    <?= $prodi; ?>
                </td>
            </tr>
            <tr>
            <tr>
                <th>Cita-cita</th>
                <td>
                    <?= $citacita; ?>
                </td>
            </tr>
            <tr>
                <th>Hobi</th>
                <td>
                    <?= $hobi; ?>
                </td>
            </tr>
            </tr>
        </table>
    </div>
    <div class="btn-container">

        <form action="/home/index">
        <button class="btn-donate">
            Biodata
        </button>
    </div>
    </form>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>