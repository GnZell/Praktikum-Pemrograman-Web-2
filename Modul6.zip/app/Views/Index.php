<!DOCTYPE html>
<html>

<head>
    <title>Halaman Index</title>
    <style>
    * {
        box-sizing: border-box;
    }

    body {
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
        margin: 0;
        padding: 0;
        background-image: url("../images/bg.jpg");
        background-size: cover;
    }
    
    ::selection {
    background-color: rgba(0, 0, 0, 0);
    }

    .container {
        max-width: 500px;
        margin: 0 auto;
        padding: 20px;
        margin-top: 100px;

        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        border-radius: 20px;

    background: radial-gradient(circle, white 0%, #d5d5d5 100%);

    border-radius: 20px;
    position: relative;
    box-shadow: 3px 3px 17px 0px rgba(0, 0, 0, 0.55);
    }

    h1 {
        color: #333;
        text-align: center;
        margin-bottom: 20px;
    }

    table {
        width: 100%;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
    }

    th {
        width: 30%;
    }

    .btn-container {
            display: flex;
            justify-content: center;
        }

    .btn-donate {
    --clr-font-main: hsla(0 0% 20% / 100);
    --btn-bg-1: gray;
    --btn-bg-2: lightgray;
    --btn-bg-color: white;
    --radii: 0.5em;
    cursor: pointer;
    margin-top: 15px;
    padding: 0.5rem 1.0rem;
    min-width: 120px;
    min-height: 44px;
    font-size: var(--size, 1rem);
    font-family: "Segoe UI", system-ui, sans-serif;
    font-weight: 500;
    transition: 0.8s;
    background-size: 280% auto;
    background-image: linear-gradient(325deg, var(--btn-bg-2) 0%, var(--btn-bg-1) 55%, var(--btn-bg-2) 90%);
    border: none;
    border-radius: var(--radii);
    color: var(--btn-bg-color);
    }

    .btn-donate:hover {
    background-position: right top;
    }

    .btn-donate:is(:focus, :focus-within,:active) {
    outline: none;
    box-shadow: 0 0 0 3px var(--btn-bg-color), 0 0 0 6px var(--btn-bg-2);
    }

    @media (prefers-reduced-motion: reduce) {
    .btn-donate {
        transition: linear;
    }
    }

    </style>

</head>

<body>
    <div class="container">
        <h1>Profile</h1>
        <table>
            <tr>
                <th>Nama</th>
                <td>
                    <?= $nama ?>
                </td>
            </tr>
            <tr>
                <th>NIM</th>
                <td>
                    <?= $nim ?>
                </td>
            </tr>
        </table>
        <div class="btn-container">
            <form action="/home/biodata">
            <button class="btn-donate">
                Biodata
            </button>
            </form>
        </div>
    </div>
</body>

</html>