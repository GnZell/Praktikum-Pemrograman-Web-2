<?php

namespace App\Models;

use CodeIgniter\Model;

class biodatamodel extends Model
{
    protected $nama = "Septian Dwi Anggoro Mochtar";
    protected $ttl = "Landasan Ulin, 24 September 2003";
    protected $nim = "2110817110007";
    protected $prodi = "Teknologi Informasi";
    protected $cita_cita = "IT Support";
    protected $hobi = "Bermain Game, Olahraga";




    protected $foto1 = "Foto.JPG";

    public function getNama()
    {
        return $this->nama;
    }
    public function getTTL()
    {
        return $this->ttl;
    }
    public function getNim()
    {
        return $this->nim;
    }
    public function getProdi()
    {
        return $this->prodi;
    }
    public function getcita_cita()
    {
        return $this->cita_cita;
    }
    public function gethobi()
    {
        return $this->hobi;
    }

    public function getFoto1()
    {
        return $this->foto1;
    }
}